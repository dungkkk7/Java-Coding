/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package defautPacket;

/**
 *
 * @author 84823
 */
public class Main {

    private static final TaskManager taskmanege = new TaskManager();

    public static void main(String[] args) {
        while (true) {
            System.out.println("1.addTask:");
            System.out.println("2.deleteTask:");
            System.out.println("3.showTask:");
            int choice = InputGetter.getChoice("Enter the choice");
            switch (choice) {
                case 1:

                    int ID = taskmanege.addTask();
                    System.out.println("ID add suceessfully" + ID);

                    break;
                case 2:
                    String taskID = InputGetter.getString("Enter the taskID delete:", "[0-9]*");
                    taskmanege.deletask(taskID);
                    System.out.println("Delete sucessfully ID");
                    break;

                case 3:
                    System.out.println("----------------------------------------- Task ---------------------------------------");
                    System.out.printf("%-10s %-15s %-20s %-25s %-10s %-20s %-20s \n", "ID", "requirmentName", "taskType",
                            "Date", "Time", "Assignee", "reviewer");
                    for (Task a : taskmanege.getshowTask()) {
                        System.out.println(a);
                    }
                    break;
            }
        }
    }

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package defautPacket;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;

/**
 *
 * @author 84823
 */
public class InputGetter {

    private static final Scanner sc = new Scanner(System.in);

    public static String getString(String mess, String regex) {
        while (true) {
            System.out.println(mess);
            try {
                String value = sc.nextLine().trim();
                if (value.isEmpty()) {
                    throw new NullPointerException("The value not empty");
                }
                if (value.matches(regex)) {
                    return value;
                } else {
                    System.out.println("Invalid Value !");
                }
            } catch (NullPointerException e) {

                System.out.println("Try again !");
            }
        }
    }

    public static int getInt(String mess, int min, int max) {
        while (true) {
            System.out.println(mess);
            try {
                int value = Integer.parseInt(sc.nextLine().trim());
                if (value >= min && value <= max) {
                    return value;
                } else {
                    System.out.println("Invalid value:");
                }
            } catch (NumberFormatException e) {
                System.out.println("Try again !");

            }

        }

    }

    public static double getDouble(String mess, double min, double max) {
        while (true) {
            System.out.println(mess);
            try {
                double value = Double.parseDouble(sc.nextLine().trim());
                if (value >= min && value <= max) {
                    if ((value % 0.5 == 0)) {
                        return value;
                    }
                } else {
                    System.out.println("Invalid value:");
                }
            } catch (NumberFormatException e) {
                System.out.println("Try again !");
            }
        }

    }



    public static int getChoice(String mess) {

        while (true) {
            System.out.println(mess);
            try {
                int choice = Integer.parseInt(sc.nextLine().trim());
                if (choice == 1 || choice == 2 || choice == 3 || choice == 4) {
                    return choice;
                } else {
                    System.out.println("Invalid choice;");
                }
            } catch (NumberFormatException e) {
                System.out.println("Try again !");

            }
        }

    }

    public static String getDate(String mess) {
        while (true) {
            System.out.println(mess);
            try {
                String value = sc.nextLine().trim();
                if (value.isEmpty()) {
                    throw new NullPointerException("This is empty:");
                }
                if (checkIsValidDate(value)) {
                    return value;
                } else {
                    System.out.println("Invalid value");
                }
            } catch (NullPointerException e) {
                System.out.println("Try again");

            }
        }
    }

    public static boolean checkIsValidDate(String value) {
        if (!value.matches("\\d{2}-\\d{2}-\\d{4}")) {
            return false;
        }
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        dateFormat.setLenient(false);

        try {
            dateFormat.parse(value);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }

}

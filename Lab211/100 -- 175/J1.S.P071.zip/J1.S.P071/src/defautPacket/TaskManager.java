/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package defautPacket;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author 84823
 */
public class TaskManager {

    private List<Task> taskList = new ArrayList<>();
    private static ArrayList<TaskType> taskTypeList = createTaskTypes();

    private int LastId = 0;

    public int addTask() {
        String requirementName = InputGetter.getString("Enter the requirementName:", "^[A-Za-z]+$"); // Chỉ chấp nhận chữ cái và khoảng trắng
        int typeID = InputGetter.getInt("Enter the typeID:", 1, 4); // Không cần regex vì là số nguyên
        String Date = InputGetter.getDate("Enter the Date (dd-MM-yyyy):"); // Định dạng ngày dd/MM/yyyy
        double plantimeForm = InputGetter.getDouble("Enter the timeForm:", 8.0, 17.5); // Không cần regex vì là số thực
        double plantimeTo = InputGetter.getDouble("Enter the timeTo:", 8.0, 17.5);
        String Assignee = InputGetter.getString("Enter the Assignee:", "^[A-Za-z]+$"); // Chỉ chấp nhận chữ cái và khoảng trắng
        String Reviewer = InputGetter.getString("Enter the Reviewer:", "^[A-Za-z]+$"); // Chỉ chấp nhận chữ cái và khoảng trắng
        LastId++;
        Task newtask = new Task(LastId + "", requirementName, typeID, Date, plantimeForm, plantimeTo, Assignee, Reviewer);
        taskList.add(newtask);
        return LastId;
    }

    public void deletask(String id) {
        Task taskremove = null;
        for (Task a : taskList) {
            if (a.getId().equalsIgnoreCase(id)) {
                taskremove = a;
                break;
            }
        }
        if (taskremove != null) {
            taskList.remove(taskremove);
        } else {
            System.out.println("Task ID not found:");
        }
    }

    public List<Task> getshowTask() {
        return taskList;
    }

    private static ArrayList<TaskType> createTaskTypes() {
        taskTypeList = new ArrayList<>();
        taskTypeList.add(new TaskType(1, "Code"));
        taskTypeList.add(new TaskType(2, "Test"));
        taskTypeList.add(new TaskType(3, "Design"));
        taskTypeList.add(new TaskType(4, "Review"));

        return taskTypeList;
    }

    public static String getTaskTypes(int id) {
        for (TaskType x : taskTypeList) {
            if (x.getTaskId() == id) {
                return x.getName();
            }
        }
        return "N/A";
    }

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package defautPacket;

/**
 *
 * @author 84823
 */
public class Task {

    private String id;
    private String requirementName;
    private int taskTypeID;
    private String Date;
    private double planFrom;
    private double planTo;
    private String Assignee;
    private String Reviewer;

    public Task(String id, String requirementName, int taskTypeID, String Date, double planFrom, double planTo, String Assignee, String Reviewer) {
        this.id = id;
        this.requirementName = requirementName;
        this.taskTypeID = taskTypeID;
        this.Date = Date;
        this.planFrom = planFrom;
        this.planTo = planTo;
        this.Assignee = Assignee;
        this.Reviewer = Reviewer;
    }

    public String getId() {
        return id;
    }

    public String getRequirementName() {
        return requirementName;
    }

    public int getTaskTypeID() {
        return taskTypeID;
    }

    public String getDate() {
        return Date;
    }

    public double getPlanFrom() {
        return planFrom;
    }

    public double getPlanTo() {
        return planTo;
    }

    public String getAssignee() {
        return Assignee;
    }

    public String getReviewer() {
        return Reviewer;
    }

       @Override
    public String toString() {
        return String.format("%-10s %-15s %-20s %-25s %-10.1f %-20s %-20s \n",
                id,
                requirementName,
                TaskManager.getTaskTypes(taskTypeID),
                Date,
                planTo - planFrom,
                Assignee,
                Reviewer
                );
    }

}
